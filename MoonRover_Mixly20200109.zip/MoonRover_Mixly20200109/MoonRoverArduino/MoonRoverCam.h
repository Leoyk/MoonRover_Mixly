#ifndef	__MOONROVERCAM_H
#define	__MOONROVERCAM_H

int takePhoto(void);
int orderPicData(int num);

#endif