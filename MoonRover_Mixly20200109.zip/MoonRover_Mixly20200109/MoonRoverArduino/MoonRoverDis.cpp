#include"MoonRoverDis.h"
#include "Arduino.h"
#include "MoonRoverComm.h"

extern float disVal;

float getDistant(void){
	  return disVal;
}