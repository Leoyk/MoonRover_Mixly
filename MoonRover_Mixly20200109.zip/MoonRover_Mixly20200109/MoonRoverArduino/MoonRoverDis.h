#ifndef	__MOONROVERDIS_H
#define	__MOONROVERDIS_H


//获得并上传距离

float getDistant(void);




#endif