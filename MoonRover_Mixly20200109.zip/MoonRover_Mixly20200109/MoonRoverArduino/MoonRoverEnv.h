#ifndef	__MOONROVERENV_H
#define	__MOONROVERENV_H


//获得并上传温度

float getTemp(void);




#endif