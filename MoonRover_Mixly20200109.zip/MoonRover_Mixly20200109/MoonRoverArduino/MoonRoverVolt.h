#ifndef	__MOONROVERVOLT_H
#define	__MOONROVERVOLT_H

float solarVolt(void);
float batVolt(void);

void getVolt(void);





#endif