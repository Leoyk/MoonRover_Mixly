#ifndef	__MOONROVERMOTION_H
#define	__MOONROVERMOTION_H

float getMotion(char a);

#endif